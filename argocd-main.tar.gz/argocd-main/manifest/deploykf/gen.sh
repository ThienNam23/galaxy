#!/bin/bash

deploykf generate \
    --source-version "0.1.2" \
    --values ./custom-values.yaml \
    --output-dir ./generator
